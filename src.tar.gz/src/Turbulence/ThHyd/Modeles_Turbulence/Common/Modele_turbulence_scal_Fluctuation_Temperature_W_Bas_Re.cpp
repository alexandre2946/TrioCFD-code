/****************************************************************************
* Copyright (c) 2019, CEA
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*****************************************************************************/
//////////////////////////////////////////////////////////////////////////////
//
// File:        Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re.cpp
// Directory:   $TURBULENCE_ROOT/src/ThHyd/Modeles_Turbulence/Common/Scal
//
//////////////////////////////////////////////////////////////////////////////

#include <Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re.h>
#include <Modele_turbulence_hyd_K_Eps_Bas_Reynolds.h>
#include <Probleme_base.h>
#include <Champ_Uniforme.h>
#include <Param.h>

Implemente_instanciable(Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re,"Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re",Modele_turbulence_scal_Fluctuation_Temperature_W);

Sortie& Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::printOn(Sortie& s ) const
{
  return s << que_suis_je() << " " << le_nom();
}

Entree& Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::readOn(Entree& is )
{
  dt_impr_nusselt_=DMAXFLOAT;

  eqn.typer("Transport_Fluctuation_Temperature_W_Bas_Re");
  eqn_transport_Fluctu_Temp = ref_cast(Transport_Fluctuation_Temperature_W_Bas_Re, eqn.valeur());
  return Modele_turbulence_scal_base::readOn(is);
}
void  Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::set_param(Param& param)
{
  Modele_turbulence_scal_base::set_param(param);
  param.ajouter_non_std("Transport_Fluctuation_Temperature_W_Bas_Re",this);
  param.ajouter_non_std("Modele_Fonc_Bas_Reynolds_Thermique",this);
  // on ajoute pas les params de la classe mere car ce n'etait pas fait avt
}
int Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::lire_motcle_non_standard(const Motcle& mot, Entree& s)
{

  Cerr << "Lecture des parametres du modele de fluctuation thermique." << finl;
  //Motcle accouverte = "{" , accfermee = "}" ;
  Motcles les_mots(2);
  {
    les_mots[0] = "Transport_Fluctuation_Temperature_W_Bas_Re";
    les_mots[1] = "Modele_Fonc_Bas_Reynolds_Thermique";
  }
  int rang=les_mots.search(mot);
  switch(rang)
    {
    case 0:
      {
        Cerr << "Lecture de l'equation Transport_Fluctuation_Temperature_W_Bas_Re" << finl;
        eqn_transport_Fluctu_Temp->associer_modele_turbulence(*this);
        s >> eqn_transport_Fluctu_Temp.valeur();
        break;
      }
    case 1:
      {
        Cerr << "Lecture du modele bas reynolds associe " << finl;
        Modele_Fonc_Bas_Reynolds_Thermique_Base::typer_lire_Modele_Fonc_Bas_Reynolds_Thermique(mon_modele_fonc, eqn_transport_Fluctu_Temp.valeur(), s);
        mon_modele_fonc->discretiser();
        Cerr << "mon_modele_fonc.que_suis_je() " << mon_modele_fonc->que_suis_je() << finl;
        break;
      }

    default :
      {
        return  Modele_turbulence_scal_base::lire_motcle_non_standard(mot,s);
      }
    }
  return 1;
}

int Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::preparer_calcul()
{
  eqn_transport_Fluctu_Temp->preparer_calcul();
  Modele_turbulence_scal_base::preparer_calcul();
  calculer_diffusivite_turbulente();
  diffusivite_turbulente_->valeurs().echange_espace_virtuel();
  return 1;
}

Champ_Fonc_base& Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::calculer_diffusivite_turbulente()
{

  DoubleTab& alpha_t = diffusivite_turbulente_->valeurs();
  const DoubleTab& nu_t = la_viscosite_turbulente->valeurs();
  double temps = la_viscosite_turbulente->temps();
  const DoubleTab& chFluctuTemp = eqn_transport_Fluctu_Temp->inconnue().valeurs();
  const Domaine_dis_base& le_dom_dis = eqn_transport_Fluctu_Temp->domaine_dis();

  const Probleme_base& mon_pb = mon_equation_->probleme();
  const Equation_base& eqn_hydr = mon_pb.equation(0);
  const RefObjU& modele_turbulence = eqn_hydr.get_modele(TURBULENCE);
  const Modele_turbulence_hyd_K_Eps_Bas_Reynolds& mod_turb_hydr = ref_cast(Modele_turbulence_hyd_K_Eps_Bas_Reynolds,modele_turbulence.valeur());
  const Transport_K_Eps_base& eqBasRe = mod_turb_hydr.eqn_transp_K_Eps();
  const DoubleTab& K_eps_Bas_Re = eqBasRe.inconnue().valeurs();

  //on recupere les proprietes physiques du fluide : viscosite cinematique et diffusivite
  const Fluide_base& fluide = ref_cast(Fluide_base,eqn_hydr.milieu());
  const Champ_Don_base& ch_visco_cin = fluide.viscosite_cinematique();
  const Champ_Don_base& ch_diffu = fluide.diffusivite();
  const DoubleTab& tab_visco = ch_visco_cin.valeurs();
  const DoubleTab& tab_diffu = ch_diffu.valeurs();
  double visco,diffu;

  if (sub_type(Champ_Uniforme,ch_visco_cin))
    {
      visco = std::max(tab_visco(0,0),DMINFLOAT);
    }
  else
    {
      visco=-1;
      Cerr << "La viscosite doit etre uniforme !!!!" << finl;
      exit();
    }

  if (sub_type(Champ_Uniforme,ch_diffu))
    {
      diffu = std::max(tab_diffu(0,0),DMINFLOAT);
    }
  else
    {
      diffu=-1;
      Cerr << "La diffusivite doit etre uniforme !!!!" << finl;
      exit();
    }

  int nb_elem = K_eps_Bas_Re.dimension(0);
  DoubleTab Flambda(nb_elem);
  mon_modele_fonc->Calcul_Flambda( Flambda,le_dom_dis,K_eps_Bas_Re,chFluctuTemp,visco,diffu);

  if (temps != diffusivite_turbulente_->temps())
    {
      static const double C_Lambda = 0.11;
      int n= alpha_t.size();
      if (nu_t.size() != n)
        {
          Cerr << "Les DoubleTab des champs diffusivite_turbulente et viscosite_turbulente" << finl;
          Cerr << "doivent avoir le meme nombre de valeurs nodales" << finl;
          exit();
        }

      for (int i=0; i<n; i++)
        {
          if (  (K_eps_Bas_Re(i,1) > 1.e-10 ) && (chFluctuTemp(i,1) > 1.e-10) && (K_eps_Bas_Re(i,0) > 1.e-10 ) && (chFluctuTemp(i,0) > 1.e-10))
            alpha_t[i] =C_Lambda*Flambda(i)*K_eps_Bas_Re(i,0)*sqrt((K_eps_Bas_Re(i,0)/K_eps_Bas_Re(i,1))*(chFluctuTemp(i,0)/(2*chFluctuTemp(i,1))));
          else
            {
              alpha_t[i] = 0.0000001;
            }
        }
      diffusivite_turbulente_->changer_temps(temps);
    }

  return diffusivite_turbulente_;
}



void Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::completer()
{
  eqn_transport_Fluctu_Temp->completer();
  const Probleme_base& mon_pb = mon_equation_->probleme();
  const RefObjU& modele_turbulence = mon_pb.equation(0).get_modele(TURBULENCE);
  const Modele_turbulence_hyd_base& mod_turb_hydr = ref_cast(Modele_turbulence_hyd_base,modele_turbulence.valeur());
  const Champ_Fonc_base& visc_turb = mod_turb_hydr.viscosite_turbulente();
  associer_viscosite_turbulente(visc_turb);
}

void Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::mettre_a_jour(double temps)
{
  Schema_Temps_base& sch1 = eqn_transport_Fluctu_Temp->schema_temps();
  // Voir Schema_Temps_base::faire_un_pas_de_temps_pb_base
  eqn_transport_Fluctu_Temp->domaine_Cl_dis().mettre_a_jour(temps);
  sch1.faire_un_pas_de_temps_eqn_base(eqn_transport_Fluctu_Temp.valeur());
  eqn_transport_Fluctu_Temp->mettre_a_jour(temps);
  eqn_transport_Fluctu_Temp->controler_grandeur();
  calculer_diffusivite_turbulente();
  diffusivite_turbulente_->valeurs().echange_espace_virtuel();
}

bool Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::has_champ(const Motcle& nom, OBS_PTR(Champ_base)& ref_champ) const
{
  if (Modele_turbulence_scal_Fluctuation_Temperature_W::has_champ(nom, ref_champ))
    return true;

  if (mon_modele_fonc.non_nul())
    if (mon_modele_fonc->has_champ(nom, ref_champ))
      return true;

  return false; /* rien trouve */
}

bool Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::has_champ(const Motcle& nom) const
{
  if (Modele_turbulence_scal_Fluctuation_Temperature_W::has_champ(nom))
    return true;

  if (mon_modele_fonc.non_nul())
    if (mon_modele_fonc->has_champ(nom))
      return true;

  return false; /* rien trouve */
}

const Champ_base& Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::get_champ(const Motcle& nom) const
{
  OBS_PTR(Champ_base) ref_champ;

  if (Modele_turbulence_scal_Fluctuation_Temperature_W::has_champ(nom, ref_champ))
    return ref_champ;

  if (mon_modele_fonc.non_nul())
    if (mon_modele_fonc->has_champ(nom, ref_champ))
      return ref_champ;

  throw std::runtime_error(std::string("Field ") + nom.getString() + std::string(" not found !"));
}

void Modele_turbulence_scal_Fluctuation_Temperature_W_Bas_Re::get_noms_champs_postraitables(Noms& nom,Option opt) const
{
  Modele_turbulence_scal_Fluctuation_Temperature_W::get_noms_champs_postraitables(nom,opt);

  if (mon_modele_fonc.non_nul())
    mon_modele_fonc->get_noms_champs_postraitables(nom,opt);
}
