/****************************************************************************
* Copyright (c) 2019, CEA
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*****************************************************************************/
//////////////////////////////////////////////////////////////////////////////
//
// File:        Source_Transport_Fluctuation_Temperature_W_VDF_Elem.cpp
// Directory:   $TURBULENCE_ROOT/src/Specializations/VDF/Sources/UNUSED
//
//////////////////////////////////////////////////////////////////////////////


#include <Source_Transport_Fluctuation_Temperature_W_VDF_Elem.h>
#include <Convection_Diffusion_Temperature.h>
#include <Modele_turbulence_scal_base.h>
#include <Fluide_base.h>
#include <Probleme_base.h>
#include <TRUSTTrav.h>
#include <Dirichlet_entree_fluide_leaves.h>
#include <Champ_Uniforme.h>
#include <Domaine_VDF.h>
#include <Champ_Face_VDF.h>
#include <Domaine_Cl_VDF.h>
#include <Modele_turbulence_hyd_K_Eps_Bas_Reynolds.h>
#include <TRUSTTrav.h>

Implemente_instanciable_sans_constructeur(Source_Transport_Fluctuation_Temperature_W_VDF_Elem,"Source_Transport_Fluctuation_Temperature_W_VDF_P0_VDF",Source_base);

//// printOn
//

Sortie& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::printOn(Sortie& s ) const
{
  return s << que_suis_je() ;
}


//// readOn
//

Entree& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::readOn(Entree& is )
{
  Motcle accolade_ouverte("{");
  Motcle accolade_fermee("}");
  Motcle motlu;

  is >> motlu;
  if (motlu != accolade_ouverte)
    {
      Cerr << "On attendait { pour commencer a lire les constantes de Source_Transport_Fluctuation_Temperature_W" << finl;
      exit();
    }
  Cerr << "Lecture des constantes de Source_Transport_Fluctuation_Temperature_W" << finl;
  Motcles les_mots(4);
  {
    les_mots[0] = "Ca";
    les_mots[1] = "Cb";
    les_mots[2] = "Cc";
    les_mots[3] = "Cd";
  }
  is >> motlu;
  while (motlu != accolade_fermee)
    {
      int rang=les_mots.search(motlu);
      switch(rang)
        {
        case 0 :
          {
            is >> Ca;
            break;
          }
        case 1 :
          {
            is >> Cb;
            break;
          }
        case 2 :
          {
            is >> Cc;
            break;
          }
        case 3 :
          {
            is >> Cd;
            break;
          }
        default :
          {
            Cerr << "On ne comprend pas le mot cle : " << motlu << "dans Source_Transport_Fluctuation_Temperature_W" << finl;
            exit();
          }
        }

      is >> motlu;
    }

  return is ;
}

void Source_Transport_Fluctuation_Temperature_W_VDF_Elem::associer_pb(const Probleme_base& pb )
{
  eq_hydraulique = pb.equation(0);
  const Convection_Diffusion_Temperature& eqn_th =
    ref_cast(Convection_Diffusion_Temperature,pb.equation(1));
  eq_thermique = eqn_th;
  mon_eq_transport_Fluctu_Temp = ref_cast(Transport_Fluctuation_Temperature_W,equation());
  const Fluide_base& fluide = eq_thermique->fluide();
  beta_t = fluide.beta_t();
  gravite_ = fluide.gravite();
}

void Source_Transport_Fluctuation_Temperature_W_VDF_Elem::associer_domaines(const Domaine_dis_base& domaine_dis,
                                                                            const Domaine_Cl_dis_base& domaine_Cl_dis)
{
  le_dom_VDF = ref_cast(Domaine_VDF, domaine_dis);
  le_dom_Cl_VDF = ref_cast(Domaine_Cl_VDF, domaine_Cl_dis);
}


////////////////////////////////////////////////////////////
//
//   Methode pour determiner la production par le gradient
//   moyen de la temperature
////////////////////////////////////////////////////////////

DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer_Prod_uteta_T(const Domaine_VDF& domaine_VDF,
                                                                                      const Domaine_Cl_VDF& zcl_VDF,
                                                                                      const DoubleTab& temper,
                                                                                      const  DoubleTab& u_teta,
                                                                                      DoubleTab& uteta_T) const
{
  int nb_faces= domaine_VDF.nb_faces();
  const Domaine& le_dom=domaine_VDF.domaine();
  int nb_faces_elem = le_dom.nb_faces_elem();
  IntTrav numfa(nb_faces_elem);
  const IntTab& les_elem_faces = domaine_VDF.elem_faces();
  DoubleTrav grad_T(nb_faces);
  int nb_elem = domaine_VDF.nb_elem();
  int n0,n1;
  double dist;
  int face;
  const IntTab& face_voisins = domaine_VDF.face_voisins();
  uteta_T = 0;
  const DoubleVect& porosite_face = equation().milieu().porosite_face();
  // on calcul tout d'abord le gradient de temperature par faces.
  // Traitement des faces internes

  int premiere_face_int=domaine_VDF.premiere_face_int();

  if (Objet_U::axi)

    for (face=premiere_face_int; face<nb_faces; face++)
      {
        n0 = face_voisins(face,0);
        n1 = face_voisins(face,1);
        dist = domaine_VDF.dist_norm_axi(face);
        grad_T[face] = (temper[n1] - temper[n0])/dist;
      }
  else
    for (face=premiere_face_int; face<nb_faces; face++)
      {
        n0 = face_voisins(face,0);
        n1 = face_voisins(face,1);
        dist = domaine_VDF.dist_norm(face);
        grad_T[face] = (temper[n1] - temper[n0])/dist;
      }

  // Traitement des conditions limites de type Entree_fluide_K_Eps_impose :

  for (int n_bord=0; n_bord<domaine_VDF.nb_front_Cl(); n_bord++)
    {

      const Cond_lim& la_cl = zcl_VDF.les_conditions_limites(n_bord);

      if (sub_type(Entree_fluide_temperature_imposee,la_cl.valeur()) )
        {
          const Entree_fluide_temperature_imposee& la_cl_diri=ref_cast(Entree_fluide_temperature_imposee,la_cl.valeur());
          const Front_VF& le_bord = ref_cast(Front_VF,la_cl->frontiere_dis());
          int ndeb = le_bord.num_premiere_face();
          int nfin = ndeb + le_bord.nb_faces();
          for (face=ndeb; face<nfin; face++)
            {
              double T_imp = la_cl_diri.val_imp(face-ndeb);
              n0 = face_voisins(face,0);
              n1 = face_voisins(face,1);
              if (Objet_U::axi)
                // dist = 2*domaine_VDF.dist_norm_bord_axi(face);
                dist = domaine_VDF.dist_norm_bord_axi(face);
              else
                dist = domaine_VDF.dist_norm_bord(face);
              if (n0 != -1)
                {
                  grad_T[face] = (T_imp-temper[n0])/dist;
                }
              else   // n1 != -1
                {
                  grad_T[face] = (temper[n1]-T_imp)/dist;
                }
            }
        }
    }  // fin des conditions limites

  // On calcul ensuite uteta gradT sur chaque element.
  for (int elem=0; elem<nb_elem; elem++)
    {
      for (int i=0; i<nb_faces_elem; i++)
        numfa[i] = les_elem_faces(elem,i);

      uteta_T[elem] = (( 0.5*(u_teta[numfa[0]]*porosite_face(numfa[0]) + u_teta[numfa[dimension]]*porosite_face(numfa[dimension]))) * (0.5*(grad_T[numfa[0]]*porosite_face(numfa[0]) + grad_T[numfa[dimension]]*porosite_face(numfa[dimension]))))
                      + (( 0.5*(u_teta[numfa[1]]*porosite_face(numfa[1]) + u_teta[numfa[dimension+1]]*porosite_face(numfa[dimension+1])))*(0.5*(grad_T[numfa[1]]*porosite_face(numfa[1]) + grad_T[numfa[dimension+1]]*porosite_face(numfa[dimension+1]))));

      if (dimension ==3)
        uteta_T[elem] += ((0.5*(u_teta[numfa[2]]*porosite_face(numfa[2]) + u_teta[numfa[5]]*porosite_face(numfa[5])))
                          *(0.5*(grad_T[numfa[2]]*porosite_face(numfa[2])
                                 + grad_T[numfa[5]]*porosite_face(numfa[5]))));
    }
  return uteta_T;
}


/************************************************/
//Fonctions qui calculent le terme g*beta*teta^2
/************************************************/
DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer_gteta2(const Domaine_VDF& domaine_VDF, DoubleTab& gteta2 ,const DoubleTab& fluctu_temp, double beta,const DoubleVect& gravite) const
{
  //
  // gteta2 est discretise au centre des elements
  //

  int nb_elem = domaine_VDF.nb_elem();
  //int nb_faces= domaine_VDF.nb_faces();
  //DoubleTrav u_teta(nb_faces);
  //  const DoubleVect& porosite_face = domaine_VDF.porosite_face();
  gteta2 = 0;

  //                ------->  -------->
  // Calcul de beta.gravite . tetacarre

  //const Domaine& le_dom=domaine_VDF.domaine();
  //int nb_faces_elem = le_dom.nb_faces_elem();

  //IntTrav numfa(nb_faces_elem);
  //DoubleVect coef(dimension);

  for (int elem=0; elem<nb_elem; elem++)
    for (int dim=0; dim<dimension; dim++)
      gteta2(elem,dim) = beta*gravite(dim)*fluctu_temp(elem,0) ;
  return gteta2;
}

DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer_gteta2(const Domaine_VDF& domaine_VDF,DoubleTab& gteta2 ,const DoubleTab& fluctu_temp,const DoubleTab& beta,const DoubleVect& gravite) const
{
  //
  // gteta2 est discretise au centre des elements
  //

  int nb_elem = domaine_VDF.nb_elem();
  //int nb_faces= domaine_VDF.nb_faces();
  //DoubleTrav u_teta(nb_faces);
  //  const DoubleVect& porosite_face = domaine_VDF.porosite_face();
  gteta2 = 0;

  //                ------->  -------->
  // Calcul de beta.gravite . tetacarre

  //const Domaine& le_dom=domaine_VDF.domaine();
  //int nb_faces_elem = le_dom.nb_faces_elem();

  //IntTrav numfa(nb_faces_elem);
  //DoubleVect coef(dimension);
  //  const IntTab& les_elem_faces = domaine_VDF.elem_faces();

  for (int elem=0; elem<nb_elem; elem++)
    for (int dim=0; dim<dimension; dim++)
      gteta2(elem,dim) = beta(elem)*gravite(dim)*fluctu_temp(elem,0) ;
  return gteta2;
}


DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer_u_teta_W(const Domaine_VDF& domaine_VDF,
                                                                                  const Domaine_Cl_VDF& zcl_VDF,
                                                                                  const DoubleTab& temper,const DoubleTab& fluctu_temp,                                                                    const DoubleTab& keps,
                                                                                  const DoubleTab& alpha_turb,
                                                                                  DoubleTab& u_teta) const
{
  //                                      ---->
  // On note u_teta le vecteur alpha_turb.gradT
  //
  // Sur chaque face on calcule la composante de u_teta normale a la face

  int nb_faces= domaine_VDF.nb_faces();
  int n0,n1,n_bord;
  double alpha,dist;
  int face;
  int nb_elem = domaine_VDF.nb_elem();
  const IntTab& face_voisins = domaine_VDF.face_voisins();
  DoubleTab gteta2(nb_elem,dimension);
  const IntVect& orientation = domaine_VDF.orientation();
  u_teta = 0;

  // Traitement des faces internes


  int premiere_face_int=domaine_VDF.premiere_face_int();
  nb_faces=domaine_VDF.nb_faces();

  if (Objet_U::axi)

    for (face=premiere_face_int; face<nb_faces; face++)
      {
        n0 = face_voisins(face,0);
        n1 = face_voisins(face,1);
        dist = domaine_VDF.dist_norm_axi(face);
        alpha = 0.5*(alpha_turb(n0)+alpha_turb(n1));
        u_teta[face] = alpha*(temper[n1] - temper[n0])/dist;
      }
  else

    for (face=premiere_face_int; face<nb_faces; face++)
      {
        n0 = face_voisins(face,0);
        n1 = face_voisins(face,1);
        dist = domaine_VDF.dist_norm(face);
        alpha = 0.5*(alpha_turb(n0)+alpha_turb(n1));
        u_teta[face] = alpha*(temper[n1] - temper[n0])/dist;
      }

  // Traitement des conditions limites de type Entree_fluide_K_Eps_impose :

  for (n_bord=0; n_bord<domaine_VDF.nb_front_Cl(); n_bord++)
    {

      const Cond_lim& la_cl = zcl_VDF.les_conditions_limites(n_bord);

      if (sub_type(Entree_fluide_temperature_imposee,la_cl.valeur()) )
        {
          const Entree_fluide_temperature_imposee& la_cl_diri=ref_cast(Entree_fluide_temperature_imposee,la_cl.valeur());
          const Front_VF& le_bord = ref_cast(Front_VF,la_cl->frontiere_dis());
          int ndeb = le_bord.num_premiere_face();
          int nfin = ndeb + le_bord.nb_faces();
          for (face=ndeb; face<nfin; face++)
            {
              double T_imp = la_cl_diri.val_imp(face-ndeb);
              n0 = face_voisins(face,0);
              n1 = face_voisins(face,1);
              if (Objet_U::axi)
                dist = 2*domaine_VDF.dist_norm_bord_axi(face);
              else
                dist = 2*domaine_VDF.dist_norm_bord(face);
              if (n0 != -1)
                {
                  alpha = alpha_turb(n0);
                  u_teta[face] = alpha*(T_imp-temper[n0])/dist;
                }
              else   // n1 != -1
                {
                  alpha = alpha_turb(n1);
                  u_teta[face] = alpha*(temper[n1]-T_imp)/dist;
                }
            }
        }
    }

  const DoubleTab& g = gravite_->valeurs();
  const Champ_Don_base& ch_beta = beta_t.valeur();
  const DoubleTab& tab_beta = ch_beta.valeurs();

  //on calcule gteta2 pour corriger u_teta confermement au modele de Wrobel
  if (sub_type(Champ_Uniforme,ch_beta))
    calculer_gteta2(domaine_VDF,gteta2 ,fluctu_temp,tab_beta(0,0),g);
  else
    calculer_gteta2(domaine_VDF, gteta2 ,fluctu_temp,tab_beta,g);


  //faire ICI u_tet=utet-Cb*tau*g*Beta*theta2
  int ori,num_face,elem1,elem2;
  for (n_bord=0; n_bord<domaine_VDF.nb_front_Cl(); n_bord++)
    {
      const Cond_lim& la_cl = zcl_VDF.les_conditions_limites(n_bord);
      const Front_VF& le_bord = ref_cast(Front_VF,la_cl->frontiere_dis());
      int ndeb = le_bord.num_premiere_face();
      int nfin = ndeb + le_bord.nb_faces();
      for (num_face=ndeb; num_face<nfin; num_face++)
        {
          ori = orientation(num_face);
          elem1 = face_voisins(num_face,0);
          if (elem1 != -1)
            {
              if ( (keps(elem1,1)>1.e-10) && (fluctu_temp(elem1,1)>1.e-10) &&(keps(elem1,0)>1.e-10) && (fluctu_temp(elem1,0)>1.e-10) )
                {
                  double tau = sqrt ( keps(elem1,0)/keps(elem1,1) *         fluctu_temp(elem1,0)/fluctu_temp(elem1,1)/2 );
                  u_teta(num_face)=u_teta(num_face)-0.7*tau*gteta2(elem1,ori);
                }
            }
          else
            {
              elem2 = face_voisins(num_face,1);
              if ( (keps(elem2,1)>1.e-10) && (fluctu_temp(elem2,1)>1.e-10) &&(keps(elem2,0)>1.e-10) && (fluctu_temp(elem2,0)>1.e-10))
                {
                  double tau = sqrt ( keps(elem2,0)/keps(elem2,1) *         fluctu_temp(elem2,0)/fluctu_temp(elem2,1)/2 );
                  u_teta(num_face)=u_teta(num_face)-0.7*tau*gteta2(elem2,ori);
                }
            }
        }
    }

  // traitement des faces internes
  for (num_face=domaine_VDF.premiere_face_int(); num_face<nb_faces; num_face++)
    {
      ori = orientation(num_face);
      elem1 = face_voisins(num_face,0);
      elem2 = face_voisins(num_face,1);
      double gtet = 0.5 *( gteta2(elem1,ori) + gteta2(elem2,ori) );
      if ( (keps(elem1,1)>1.e-10) && (fluctu_temp(elem1,1)>1.e-10) && (keps(elem2,1)>1.e-10) && (fluctu_temp(elem2,1)>1.e-10))
        {
          double tau =0.5* ( sqrt ( keps(elem1,0)/keps(elem1,1) * fluctu_temp(elem1,0)/fluctu_temp(elem1,1)/2)  + sqrt(keps(elem2,0)/keps(elem2,1) * fluctu_temp(elem2,0)/fluctu_temp(elem2,1)/2) );
          u_teta(num_face)=u_teta(num_face)-0.7*tau*gtet;
        }
    }


  return u_teta;
}

DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer_terme_destruction_K_W(const Domaine_VDF& domaine_VDF,
                                                                                               const Domaine_Cl_VDF& zcl_VDF,
                                                                                               DoubleTab& G,const DoubleTab& temper,
                                                                                               const DoubleTab& fluctuTemp,
                                                                                               const DoubleTab& keps,
                                                                                               const DoubleTab& alpha_turb,
                                                                                               double beta,const DoubleVect& gravite) const
{
  //
  // G est discretise comme K et Eps i.e au centre des elements
  //
  //                                       --> ----->
  // G(elem) = beta alpha_t(elem) G . gradT(elem)
  //

  int nb_elem = domaine_VDF.nb_elem();
  int nb_faces= domaine_VDF.nb_faces();
  DoubleTrav u_teta(nb_faces);
  const DoubleVect& porosite_face = equation().milieu().porosite_face();

  //                                      ---->
  // On note u_teta le vecteur alpha_turb.gradT
  //
  // Appel a la fonction qui calcule sur chaque face la composante
  // de u_teta normale a la face

  calculer_u_teta_W(domaine_VDF,zcl_VDF,temper,fluctuTemp,keps,alpha_turb,u_teta);

  //                                          ------> ----->
  // On calcule ensuite une valeur moyenne de gravite.u_teta sur chaque
  // element.

  G = 0;

  //                ------->  ------>
  // Calcul de beta.gravite . u_teta

  const Domaine& le_dom=domaine_VDF.domaine();
  int nb_faces_elem = le_dom.nb_faces_elem();

  IntTrav numfa(nb_faces_elem);
  DoubleVect coef(Objet_U::dimension);
  const IntTab& les_elem_faces = domaine_VDF.elem_faces();

  for (int elem=0; elem<nb_elem; elem++)
    {
      for (int i=0; i<nb_faces_elem; i++)
        numfa[i] = les_elem_faces(elem,i);

      coef(0) = 0.5*(u_teta(numfa[0])*porosite_face(numfa[0])
                     + u_teta(numfa[dimension])*porosite_face(numfa[dimension]));
      coef(1) = 0.5*(u_teta(numfa[1])*porosite_face(numfa[1])
                     + u_teta(numfa[dimension+1])*porosite_face(numfa[dimension+1]));

      if (dimension ==2)
        G[elem] = beta*(gravite(0)*coef(0) + gravite(1)*coef(1));

      else if (dimension == 3)
        {
          coef(2) = 0.5*(u_teta(numfa[2])*porosite_face(numfa[2])
                         + u_teta(numfa[5])*porosite_face(numfa[5]));
          G[elem] = beta*(gravite(0)*coef(0) + gravite(1)*coef(1) + gravite(2)*coef(2));
        }

    }

  return G;
}

DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer_terme_destruction_K_W(const Domaine_VDF& domaine_VDF,
                                                                                               const Domaine_Cl_VDF& zcl_VDF,
                                                                                               DoubleTab& G,const DoubleTab& temper,
                                                                                               const DoubleTab& fluctuTemp,
                                                                                               const DoubleTab& keps,
                                                                                               const DoubleTab& alpha_turb,
                                                                                               const DoubleTab& beta,const DoubleVect& gravite) const
{
  //
  // G est discretise comme K et Eps i.e au centre des elements
  //
  //                                       --> ----->
  // G(elem) = beta(elem) alpha_t(elem) G . gradT(elem)
  //

  int nb_elem = domaine_VDF.nb_elem();
  int nb_faces= domaine_VDF.nb_faces();
  DoubleTrav u_teta(nb_faces);
  const DoubleVect& porosite_face = equation().milieu().porosite_face();

  //                                      ---->
  // On note u_teta le vecteur alpha_turb.gradT
  //
  // Appel a la fonction qui calcule sur chaque face la composante
  // de u_teta normale a la face

  calculer_u_teta_W(domaine_VDF,zcl_VDF,temper,fluctuTemp,keps,alpha_turb,u_teta);

  //                                          ------> ----->
  // On calcule ensuite une valeur moyenne de gravite.u_teta sur chaque
  // element.

  G = 0;

  //                ------->  ------>
  // Calcul de beta.gravite . u_teta

  const Domaine& le_dom=domaine_VDF.domaine();
  int nb_faces_elem = le_dom.nb_faces_elem();
  IntTrav numfa(nb_faces_elem);
  const IntTab& les_elem_faces = domaine_VDF.elem_faces();
  DoubleVect coef(dimension);

  for (int elem=0; elem<nb_elem; elem++)
    {
      for (int i=0; i<nb_faces_elem; i++)
        numfa[i] = les_elem_faces(elem,i);

      coef(0) = 0.5*(u_teta(numfa[0])*porosite_face(numfa[0])
                     + u_teta(numfa[dimension])*porosite_face(numfa[dimension]));
      coef(1) = 0.5*(u_teta(numfa[1])*porosite_face(numfa[1])
                     + u_teta(numfa[dimension+1])*porosite_face(numfa[dimension+1]));

      if (dimension ==2)
        G[elem] = beta(elem)*(gravite(0)*coef(0) + gravite(1)*coef(1));

      else if (dimension == 3)
        {
          coef(2) = 0.5*(u_teta(numfa[2])*porosite_face(numfa[2])
                         + u_teta(numfa[5])*porosite_face(numfa[5]));
          G[elem] = beta(elem)*(gravite(0)*coef(0) + gravite(1)*coef(1) + gravite(2)*coef(2));
        }

    }

  return G;
}


DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::ajouter(DoubleTab& resu) const
{
  const Domaine_Cl_dis_base& zcl = eq_hydraulique->domaine_Cl_dis();
  const Domaine_VDF& domaine_VDF = ref_cast(Domaine_VDF,eq_hydraulique->domaine_dis());
  const Domaine_Cl_VDF& domaine_Cl_VDF = ref_cast(Domaine_Cl_VDF,zcl);
  const RefObjU& modele_turbulence_hydr = eq_hydraulique->get_modele(TURBULENCE);
  const Modele_turbulence_hyd_base& le_modele = ref_cast(Modele_turbulence_hyd_base,modele_turbulence_hydr.valeur());
  const Modele_turbulence_hyd_K_Eps_Bas_Reynolds& modele_bas_Re = ref_cast(Modele_turbulence_hyd_K_Eps_Bas_Reynolds,le_modele);
  const Transport_K_Eps_base& mon_eq_transport_K_Eps_Bas_Re = modele_bas_Re.eqn_transp_K_Eps();
  const Domaine_Cl_VDF& zcl_VDF_th = ref_cast(Domaine_Cl_VDF,eq_thermique->domaine_Cl_dis());
  const DoubleTab& K_eps_Bas_Re = mon_eq_transport_K_Eps_Bas_Re.inconnue().valeurs();
  const DoubleTab& scalaire = eq_thermique->inconnue().valeurs();
  const DoubleTab& vit = eq_hydraulique->inconnue().valeurs();
  const DoubleTab& visco_turb = le_modele.viscosite_turbulente().valeurs();
  const DoubleTab& Fluctu_Temperature = mon_eq_transport_Fluctu_Temp->inconnue().valeurs();
  const DoubleVect& volumes = domaine_VDF.volumes();
  const DoubleVect& porosite_vol = equation().milieu().porosite_elem();
  const Modele_turbulence_scal_base& le_modele_scalaire =
    ref_cast(Modele_turbulence_scal_base,eq_thermique->get_modele(TURBULENCE).valeur());
  const DoubleTab& alpha_turb = le_modele_scalaire.diffusivite_turbulente().valeurs();
  const DoubleTab& g = gravite_->valeurs();
  const Champ_Don_base& ch_beta = beta_t.valeur();
  int nb_elem = domaine_VDF.nb_elem();
  int nb_elem_tot = domaine_VDF.nb_elem_tot();
  int nb_face = domaine_VDF.nb_faces();
  DoubleTrav uteta_T(nb_elem_tot);
  DoubleTrav P(nb_elem_tot);
  DoubleTrav G(nb_elem_tot);
  DoubleTrav utet(nb_face);

  calculer_u_teta(domaine_VDF,domaine_Cl_VDF,scalaire,alpha_turb,utet);

  // calculer_u_teta_W(domaine_VDF,domaine_Cl_VDF,scalaire,Fluctu_Temperature,K_eps_Bas_Re,alpha_turb,utet);

  const DoubleTab& tab_beta = ch_beta.valeurs();


  calculer_Prod_uteta_T(domaine_VDF,domaine_Cl_VDF,scalaire,utet,uteta_T);

  if (axi)
    {
      Champ_Face_VDF& vitesse = ref_cast_non_const(Champ_Face_VDF,eq_hydraulique->inconnue());
      calculer_terme_production_K_Axi(domaine_VDF,vitesse,P,K_eps_Bas_Re,visco_turb);
    }
  else
    {
      Champ_Face_VDF& vitesse = ref_cast_non_const(Champ_Face_VDF,eq_hydraulique->inconnue());
      calculer_terme_production_K(domaine_VDF,domaine_Cl_VDF,P,K_eps_Bas_Re,vit,vitesse,visco_turb);
    }

  // C'est l'objet de type domaine_Cl_dis de l'equation thermique
  // qui est utilise dans le calcul de G


  if (sub_type(Champ_Uniforme,ch_beta))
    calculer_terme_destruction_K(domaine_VDF,zcl_VDF_th,G,scalaire,alpha_turb,tab_beta(0,0),g);
  else
    calculer_terme_destruction_K(domaine_VDF,zcl_VDF_th,G,scalaire,alpha_turb,tab_beta,g);

  /*
    if (sub_type(Champ_Uniforme,ch_beta))
    calculer_terme_destruction_K_W(domaine_VDF,zcl_VDF_th,G,scalaire,Fluctu_Temperature,K_eps_Bas_Re,alpha_turb,tab_beta(0,0),g);
    else
    calculer_terme_destruction_K_W(domaine_VDF,zcl_VDF_th,G,scalaire,Fluctu_Temperature,K_eps_Bas_Re,alpha_turb,tab_beta,g);
  */

  for (int elem=0; elem<nb_elem; elem++)
    {

      resu(elem,0) += -2*(uteta_T(elem)+Fluctu_Temperature(elem,1))*volumes(elem)*porosite_vol(elem);

      double A=0;
      if (K_eps_Bas_Re(elem,0)>1.e-10)
        A=-Ca*Fluctu_Temperature(elem,1)*K_eps_Bas_Re(elem,1)/K_eps_Bas_Re(elem,0);
      double B=0;
      if (Fluctu_Temperature(elem,0)>1.e-10)
        B=-Cb*(Fluctu_Temperature(elem,1)*Fluctu_Temperature(elem,1))/Fluctu_Temperature(elem,0);
      double C=0;
      if (Fluctu_Temperature(elem,0)>1.e-10)
        C=-Cc*(Fluctu_Temperature(elem,1)/Fluctu_Temperature(elem,0))*uteta_T(elem);
      double D=0;
      if ( K_eps_Bas_Re(elem,0)>1.e-10 )
        D=+Cd*(P(elem)+G(elem))*Fluctu_Temperature(elem,1)/K_eps_Bas_Re(elem,0);
      //if (elem==45) {
      //   Cerr << "Fluctuations thermiques:" << finl;
      //   Cerr << "P=" << P(elem) << " G=" << G(elem) << " ut=" << uteta_T(elem) << finl;
      //   Cerr << "A=" << A << " B=" << B << " C=" << C << " D=" << D << finl;
      // }
      resu(elem,1) += (A+B+C+D)*volumes(elem)*porosite_vol(elem);
    }
  // Cerr << "FIN DE AJOUTER SOURCES FLUCTU TEMP resu = " << resu << finl;
  return resu;
}

DoubleTab& Source_Transport_Fluctuation_Temperature_W_VDF_Elem::calculer(DoubleTab& resu) const
{
  resu = 0;
  return ajouter(resu);
}



